//
//  ZCViewController.h
//  ZbarDemo20141009
//
//  Created by 张诚 on 14-10-9.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCViewController : UIViewController

@end
